import express from 'express';
import cors from 'cors';
import path from 'node:path';
import fs from 'node:fs';
import { router as casesRouter } from './routes/cases.js';

const app = express();
app.use(cors());
app.use(express.json({ limit: '5mb' }));

const uploadsDir = path.join(process.cwd(), 'uploads');
fs.mkdirSync(uploadsDir, { recursive: true });
app.use('/uploads', express.static(uploadsDir));

app.use('/api/cases', casesRouter);

// Serve client build if present
const clientDist = path.join(process.cwd(), '..', 'client', 'dist');
if (fs.existsSync(clientDist)) {
  app.use(express.static(clientDist));
  app.get('*', (req, res) => res.sendFile(path.join(clientDist, 'index.html')));
} else {
  app.get('/', (req, res) => res.type('text/plain').send('Client not built yet. Run npm run build:all'));
}

const port = Number(process.env.PORT ?? '3000');
app.listen(port, () => {
  // eslint-disable-next-line no-console
  console.log(`Server listening on ${port}`);
});
