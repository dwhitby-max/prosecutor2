import { useEffect, useState } from 'react';
import { PreviewUpload } from './PreviewUpload';

type CaseRow = { id: string; caseNumber: string | null; defendantName: string | null; createdAt: string };

type CasesResp =
  | { ok: true; cases: CaseRow[] }
  | { ok: false; error: string };

type CaseDetailResp =
  | { ok: true; case: { id: string; caseNumber: string | null; defendantName: string | null; createdAt: string; analysisJson: unknown; documents: Array<{ id: string; filename: string; uploadPath: string | null }> } }
  | { ok: false; error: string };

function isObj(v: unknown): v is Record<string, unknown> {
  return typeof v === 'object' && v !== null;
}

function getString(v: unknown): string | null {
  return typeof v === 'string' ? v : null;
}

export function App() {
  const [view, setView] = useState<'cases' | 'preview'>('cases');
  const [cases, setCases] = useState<CaseRow[]>([]);
  const [selected, setSelected] = useState<string | null>(null);
  const [detail, setDetail] = useState<CaseDetailResp | null>(null);

  async function loadCases() {
    const r = await fetch('/api/cases');
    const j: unknown = await r.json();
    if (!isObj(j) || j.ok !== true || !Array.isArray(j.cases)) return;
    const rows: CaseRow[] = [];
    for (const row of j.cases) {
      if (!isObj(row)) continue;
      const id = getString(row.id);
      const createdAt = getString(row.createdAt);
      if (!id || !createdAt) continue;
      rows.push({
        id,
        createdAt,
        caseNumber: getString(row.caseNumber),
        defendantName: getString(row.defendantName),
      });
    }
    setCases(rows);
  }

  useEffect(() => { void loadCases(); }, []);

  async function openCase(id: string) {
    setSelected(id);
    const r = await fetch(`/api/cases/${encodeURIComponent(id)}`);
    const j: unknown = await r.json();
    if (!isObj(j)) return;
    if (j.ok === true) setDetail(j as CaseDetailResp);
    else setDetail({ ok: false, error: getString(j.error) ?? 'Unknown error' });
  }

  return (
    <div style={{ fontFamily: 'system-ui, sans-serif' }}>
      <div style={{ display: 'flex', gap: 8, padding: 12, borderBottom: '1px solid #eee' }}>
        <button onClick={() => setView('cases')} disabled={view === 'cases'}>Cases</button>
        <button onClick={() => setView('preview')} disabled={view === 'preview'}>Preview</button>
        <button onClick={() => { void loadCases(); }}>Refresh</button>
      </div>

      {view === 'preview' ? (
        <PreviewUpload />
      ) : (
        <div style={{ padding: 16, display: 'grid', gridTemplateColumns: '320px 1fr', gap: 16 }}>
          <div>
            <h2>Cases</h2>
            <UploadCreate onCreated={() => { void loadCases(); }} />
            <div style={{ marginTop: 12 }}>
              {cases.map((c) => (
                <div key={c.id} style={{ padding: 10, border: '1px solid #ddd', borderRadius: 8, marginBottom: 8 }}>
                  <div><strong>{c.defendantName ?? 'Unknown Defendant'}</strong></div>
                  <div style={{ fontSize: 12, color: '#555' }}>
                    Case: {c.caseNumber ?? 'Unknown'} · {new Date(c.createdAt).toLocaleString()}
                  </div>
                  <button style={{ marginTop: 8 }} onClick={() => void openCase(c.id)} disabled={selected === c.id}>
                    Open
                  </button>
                </div>
              ))}
            </div>
          </div>

          <div>
            <h2>Case Detail</h2>
            {!detail && <div>Select a case.</div>}
            {detail && detail.ok === false && <div style={{ color: 'crimson' }}>{detail.error}</div>}
            {detail && detail.ok === true && (
              <div>
                <div style={{ marginBottom: 12 }}>
                  <div><strong>{detail.case.defendantName ?? 'Unknown Defendant'}</strong></div>
                  <div>Case #: {detail.case.caseNumber ?? 'Unknown'}</div>
                </div>

                <h3>Documents</h3>
                {detail.case.documents.map((d) => (
                  <div key={d.id} style={{ marginBottom: 8 }}>
                    {d.uploadPath ? <a href={d.uploadPath} target="_blank">{d.filename}</a> : d.filename}
                  </div>
                ))}

                <h3>Analysis JSON</h3>
                <pre style={{ whiteSpace: 'pre-wrap', background: '#f7f7f7', padding: 12, borderRadius: 8 }}>
                  {JSON.stringify(detail.case.analysisJson, null, 2)}
                </pre>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

function UploadCreate(props: { onCreated: () => void }) {
  const [files, setFiles] = useState<FileList | null>(null);
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);

  async function submit() {
    if (!files || files.length === 0) return;
    const fd = new FormData();
    for (const f of Array.from(files)) fd.append('pdfs', f);
    setLoading(true);
    setMsg(null);
    try {
      const r = await fetch('/api/cases/upload', { method: 'POST', body: fd });
      const j: unknown = await r.json();
      if (isObj(j) && j.ok === true) {
        setMsg('Created.');
        props.onCreated();
      } else {
        setMsg(isObj(j) ? (getString(j.error) ?? 'Error') : 'Error');
      }
    } catch (e) {
      const m = e instanceof Error ? e.message : 'Error';
      setMsg(m);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={{ border: '1px solid #ddd', borderRadius: 8, padding: 12 }}>
      <div><strong>Upload PDFs (creates cases)</strong></div>
      <input type="file" accept="application/pdf" multiple onChange={(e) => setFiles(e.target.files)} />
      <div style={{ marginTop: 8 }}>
        <button onClick={submit} disabled={loading || !files || files.length === 0}>{loading ? 'Working…' : 'Upload'}</button>
        {msg && <span style={{ marginLeft: 8 }}>{msg}</span>}
      </div>
    </div>
  );
}
